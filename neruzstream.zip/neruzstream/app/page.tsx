const lives = [
  { id: 1, titulo: "Roleplay em São Paulo", streamer: "CidadePaulista", categoria: "GTA RP", viewers: 342 },
  { id: 2, titulo: "Ranked insana no Valorant", streamer: "Rian", categoria: "FPS", viewers: 128 },
  { id: 3, titulo: "Só resenha e bate-papo", streamer: "NeruzTV", categoria: "Just Chatting", viewers: 89 },
  { id: 4, titulo: "Farmando no RP", streamer: "PaulistaLive", categoria: "GTA RP", viewers: 210 },
];

export default function Page() {
  return (
    <div className="min-h-screen bg-[#050816] text-gray-100">
      {/* HEADER */}
      <header className="border-b border-white/10 bg-black/30 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400" />
            <div className="flex flex-col leading-tight">
              <span className="text-sm font-semibold text-violet-300">
                Plataforma
              </span>
              <span className="text-lg font-bold tracking-tight">
                NeruzStream
              </span>
            </div>
          </div>

          <nav className="hidden gap-6 text-sm font-medium text-gray-300 md:flex">
            <button className="hover:text-white">Explorar</button>
            <button className="hover:text-white">Categorias</button>
            <button className="hover:text-white">Sobre</button>
          </nav>

          <div className="flex items-center gap-3">
            <input
              type="text"
              placeholder="Buscar lives..."
              className="hidden rounded-xl bg-white/5 px-3 py-1.5 text-sm outline-none placeholder:text-gray-500 focus:ring-2 focus:ring-violet-500 md:block"
            />
            <button className="rounded-xl bg-violet-600 px-4 py-1.5 text-sm font-semibold hover:bg-violet-500">
              Entrar
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8 space-y-12">
        {/* HERO */}
        <section className="grid gap-8 md:grid-cols-[3fr,2fr] items-center">
          <div>
            <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">
              A casa das suas{" "}
              <span className="bg-gradient-to-r from-violet-400 to-cyan-300 bg-clip-text text-transparent">
                lives
              </span>
              .
            </h1>
            <p className="mt-3 text-sm md:text-base text-gray-300 max-w-xl">
              Transmita sua gameplay, resenha ou projeto e construa sua
              comunidade. Tudo em um lugar pensado pra quem vive o mundo
              streamer.
            </p>
            <div className="mt-5 flex flex-wrap gap-3">
              <button className="rounded-xl bg-violet-600 px-5 py-2 text-sm font-semibold hover:bg-violet-500">
                Começar a transmitir
              </button>
              <button className="rounded-xl border border-white/10 px-5 py-2 text-sm font-semibold text-gray-200 hover:border-violet-400">
                Explorar lives
              </button>
            </div>

            <div className="mt-6 flex gap-6 text-xs text-gray-400">
              <div>
                <span className="block text-sm font-semibold text-gray-100">
                  +150
                </span>
                criadores ativos
              </div>
              <div>
                <span className="block text-sm font-semibold text-gray-100">
                  Baixo delay
                </span>
                focado em RP e gameplay
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="h-56 w-full rounded-3xl bg-gradient-to-br from-violet-700/70 via-fuchsia-500/40 to-cyan-400/70 p-[2px] shadow-xl">
              <div className="flex h-full flex-col justify-between rounded-3xl bg-[#050816] p-4">
                <div className="flex items-center justify-between text-xs">
                  <span className="rounded-full bg-red-600 px-2 py-0.5 text-[11px] font-semibold">
                    AO VIVO
                  </span>
                  <span className="text-gray-300">342 assistindo</span>
                </div>
                <div className="flex flex-1 items-center justify-center">
                  <span className="text-xs text-gray-400">
                    Preview da transmissão
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <div>
                    <div className="font-semibold">Cidade Paulista RP</div>
                    <div className="text-gray-400">GTA Roleplay • Português</div>
                  </div>
                  <button className="rounded-xl bg-violet-600 px-3 py-1 text-[11px] font-semibold hover:bg-violet-500">
                    Assistir agora
                  </button>
                </div>
              </div>
            </div>
            <div className="pointer-events-none absolute -bottom-6 -left-4 h-16 w-16 rounded-3xl bg-cyan-400/30 blur-2xl" />
            <div className="pointer-events-none absolute -top-4 -right-4 h-16 w-16 rounded-3xl bg-violet-500/30 blur-2xl" />
          </div>
        </section>

        {/* LIVES AO VIVO */}
        <section>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold">Lives ao vivo agora</h2>
            <button className="text-xs text-violet-300 hover:text-violet-200">
              Ver todas
            </button>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {lives.map((live) => (
              <div
                key={live.id}
                className="group rounded-2xl bg-white/5 p-2 hover:bg-white/10 transition"
              >
                <div className="relative h-32 w-full overflow-hidden rounded-xl bg-gradient-to-br from-violet-700 to-cyan-500">
                  <span className="absolute left-2 top-2 rounded-full bg-red-600 px-2 py-0.5 text-[10px] font-semibold">
                    AO VIVO
                  </span>
                  <span className="absolute bottom-2 left-2 rounded-full bg-black/60 px-2 py-0.5 text-[10px] text-gray-100">
                    {live.categoria}
                  </span>
                  <span className="absolute bottom-2 right-2 rounded-full bg-black/60 px-2 py-0.5 text-[10px] text-gray-100">
                    {live.viewers} assistindo
                  </span>
                </div>
                <div className="mt-2 px-1 pb-1">
                  <p className="text-sm font-semibold line-clamp-1">
                    {live.titulo}
                  </p>
                  <p className="text-xs text-gray-400">{live.streamer}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* MOCK PÁGINA DA LIVE + PAINEL STREAMER (VISUAL) */}
        <section className="grid gap-6 md:grid-cols-2">
          {/* Página da live (visual) */}
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <h3 className="mb-2 text-sm font-semibold text-gray-300">
              Exemplo – Página da Live
            </h3>
            <div className="space-y-3 text-xs text-gray-300">
              <div className="h-32 rounded-xl bg-black/60 flex items-center justify-center">
                Player da live (vídeo)
              </div>
              <div className="flex justify-between text-[11px]">
                <div>
                  <div className="font-semibold">CidadePaulista</div>
                  <div className="text-gray-400">
                    Roleplay pesado no centro de SP
                  </div>
                </div>
                <button className="rounded-lg bg-violet-600 px-3 py-1 font-semibold text-[11px] hover:bg-violet-500">
                  Seguir
                </button>
              </div>
              <div className="flex gap-3 text-[11px] text-gray-400">
                <span>💬 Chat lateral</span>
                <span>👥 Viewers ao vivo</span>
                <span>📌 Categoria GTA RP</span>
              </div>
            </div>
          </div>

          {/* Painel do streamer (visual) */}
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <h3 className="mb-2 text-sm font-semibold text-gray-300">
              Exemplo – Painel do Streamer
            </h3>
            <div className="space-y-3 text-xs text-gray-300">
              <div className="grid gap-2 md:grid-cols-2">
                <div className="flex flex-col gap-1">
                  <label className="text-[11px] text-gray-400">
                    Título da live
                  </label>
                  <input
                    className="rounded-lg bg-black/40 px-2 py-1 text-xs outline-none focus:ring-1 focus:ring-violet-500"
                    defaultValue="Farmando RP na Cidade Paulista"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[11px] text-gray-400">
                    Categoria
                  </label>
                  <select className="rounded-lg bg-black/40 px-2 py-1 text-xs outline-none focus:ring-1 focus:ring-violet-500">
                    <option>GTA RP</option>
                    <option>Just Chatting</option>
                    <option>FPS</option>
                    <option>IRL</option>
                  </select>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 rounded-lg bg-black/30 px-3 py-2">
                <div className="flex-1">
                  <div className="text-[11px] text-gray-400">
                    Sua chave de stream (RTMP)
                  </div>
                  <div className="text-[11px] font-mono">
                    rtmp://neruzstream/live/SEU_USUARIO
                  </div>
                </div>
                <button className="rounded-lg bg-violet-600 px-3 py-1 text-[11px] font-semibold hover:bg-violet-500">
                  Copiar chave
                </button>
              </div>

              <div className="grid grid-cols-3 gap-3 text-center text-[11px]">
                <div className="rounded-lg bg-black/40 p-2">
                  <div className="text-xs font-semibold">342</div>
                  <div className="text-gray-400">Viewers agora</div>
                </div>
                <div className="rounded-lg bg-black/40 p-2">
                  <div className="text-xs font-semibold">1.254</div>
                  <div className="text-gray-400">Seguidores</div>
                </div>
                <div className="rounded-lg bg-black/40 p-2">
                  <div className="text-xs font-semibold">36h</div>
                  <div className="text-gray-400">Este mês</div>
                </div>
              </div>

              <div className="mt-1 text-[11px] text-gray-400">
                Depois aqui entra o histórico de lives, configurações avançadas,
                layout de alertas etc.
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
